/* @Author Dave White - 04-21-2017
 * Project = stats.c
 *
 * This program computes mean, median, min, max, 
 * sorts (from high to low), and prints the contents
 * of an n-length array. 
 */
